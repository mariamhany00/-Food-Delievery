import { useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import './components/style.css'
import Delivery from './components/Delievry'
import Healthy from './components/Healthy'
import HProduct from './components/HProduct'
import ProductSlider from './components/ProductSlider'
import SProduct from './components/SProduct'
import Products from './components/Products'
import Product from './components/Product'
import Footer from './components/Footer'
function App() {
  const [count, setCount] = useState(0)

  return (
   <>
   <Navbar/>
   <Hero/>
   <Delivery/>
   <Healthy/>
   <HProduct/>
   <ProductSlider/>
   <SProduct/>
   <Products/>
   <Product/>
   <Footer/>
   
   </>
  )
}

export default App
