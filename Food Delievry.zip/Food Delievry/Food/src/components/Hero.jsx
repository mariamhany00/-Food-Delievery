import Certificate from '../assets/Images/certi.png';
import HeroImage from '../assets/images/hero1.png';

const Hero = () => {
  return (
    <div className="container-fluid px-4 py-5 hero-container">
      <div className="row align-items-center g-5">
        <div className="col-lg-6 py-5 hero-text">
          <h1 className="display-1 fw-bold lh-1 mb-3">
            <span>Your Online Farmers Market</span>
          </h1>
          <div className="d-flex align-items-center my-5">
            <img src={Certificate} alt="" className="me-3"/>
            <p className="fw-bold">We deliver organic vegetables fresh from 
                <br />our fields to your doorstep.</p>
          </div>
          <div className="d-grid gap-2 d-md-flex justify-content-md-start">
            <button type="button" className="btn btn-warning btn-lg px-4 me-md-2 rounded-0">
              Shop Your Veg
            </button>
            <button type="button" className="btn btn-light btn-lg px-4 rounded-0">
              Shop All Products
            </button>
          </div>
        </div>
        <div className="col-10 col-sm-8 col-lg-6 hero-image-container">
          <img
            src={HeroImage}
            className="d-block mx-lg-auto img-fluid hero-image"
            alt="Hero Image"
            loading="lazy"
          />
        </div>
      </div>
    </div>
  );
};

export default Hero;
